package com.main.exception;

public class MutualFundPurchaseException extends Exception {
	public MutualFundPurchaseException(String message) {
        super(message);
    }
}