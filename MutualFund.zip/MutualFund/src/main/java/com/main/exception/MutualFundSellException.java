package com.main.exception;

public class MutualFundSellException extends Exception {
	
	public MutualFundSellException(String message) {
        super(message);
    }
}